#ifndef __DATATYPES_INCLUDE_H__
#define __DATATYPES_INCLUDE_H__

typedef float data_t;
typedef float coef_t;
typedef float acc_t;
typedef float param_t;

#endif
