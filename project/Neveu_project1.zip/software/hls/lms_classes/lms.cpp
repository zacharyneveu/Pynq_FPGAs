#include "lms_class.h"
#include "datatypes.h"

#define L   50
data_t lms(data_t x, data_t y, param_t mu)
{
    static LMS<L> lms;
    return lms.process(x, y, mu);
}
