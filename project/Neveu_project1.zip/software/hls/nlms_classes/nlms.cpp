#include "nlms_class.h"
#include "datatypes.h"

#define L   50
data_t lms(data_t x, data_t y, param_t mu, param_t delta)
{
    static NLMS<L> nlms;
    return nlms.process(x, y, mu, delta);
}
